from datetime import date
import os
from django.shortcuts import render,redirect
from django.http import FileResponse, HttpResponse
from tour_and_travalling import models
from tour_and_travalling.models import *
from django.contrib.auth.models import User
from django.contrib.auth import login,logout,authenticate
import uuid


import re

# Sample users (email: password)
users = {
    "test@example.com": "Secure123",
    "user@domain.com": "Password1"
}

# Email validation
def is_valid_email(email):
    pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'
    return re.match(pattern, email)

# Password validation

def is_valid_password(password):
    if len(password) < 6:
        print("❌ Password must be at least 6 characters.")
        return False
    if not re.search(r'[A-Z]', password):
        print("❌ Must include at least one uppercase letter.")
        return False
    if not re.search(r'[a-z]', password):
        print("❌ Must include at least one lowercase letter.")
        return False
    if not re.search(r'\d', password):
        print("❌ Must include at least one number.")
        return False
    return True

# Login function
def login_valide(email,confirm_email,password):
    
    if not is_valid_email(email):
        print("❌ Invalid email format.")
        return

    
    if not is_valid_password(password):
        return
    
    if email != confirm_email:
        print("❌ Emails do not match.")
        return
    return True



def index(request):
    
    if request.method=="POST":
     pack=package.objects.all()
     search=request.POST.get('search')
     return render(request,'home/index.html',{'pack':pack,'search':search})
    
    pack=package.objects.all()
    return render(request,"home/index.html",{'pack':pack} )
    

def admin_home(request):
 return render(request,"admin_home.html")

def search(request):
    
    return render(request,"home/search.html")

def offers(request):
    pack=package.objects.all()
    return render(request,"home/offers.html",{'pack':pack})


def loginuser(request):  
      if request.method=='POST':
          name=request.POST.get('name')
          password=request.POST.get('pass')
          user=authenticate(username=name,password=password)
          if user is not None:
           login(request,user)
           return redirect('index')
          
          elif name=='parth_ramanujj' and password=='parth':
            
            return redirect('superadmin')
          else:
            return redirect('login')
        #   else:
        #       return render(request,"home/index.html")
      context={
          'login1':user_login.objects.all()
      }      
      return render(request,"home/login.html",context)
       
def logout_user(request):
        logout(request)
        return  redirect('index')

def register(request):
    
    if request.method=='POST':
          name=request.POST.get('name')
          email=request.POST.get('email')
          password=request.POST.get('pass')
          conpassword=request.POST.get('cpass')
          image=request.POST.get('image')
          reg=ragister(name=name,email_id=email,password=password,conpassword=conpassword,image=image)
          reg.save()
          my_use=User.objects.create_user(name,email,password)
          my_use.save()
          return redirect("login")
        #   if login_valide(email,conpassword,password):
              
        #       print("ragister successfull...")
        #       return render(request,"home/login.html")
        #   name=request.POST.get('name')
        #   print(email+password+conpassword+name)
          
    return render(request,"home/register.html" )

def bookingtour(request):
    if request.method=="POST":
        #name=User.username
        name=request.POST.get('destination')
        checkin=request.POST.get('checkin')
        checkout=request.POST.get('checkout')
        adults=int(request.POST.get('adults'))
        children=int(request.POST.get('children'))
        roomtype=request.POST.get('roomtype')
        adharcard=request.POST.get('adharcard')
        phone=request.POST.get('phonenumbr')
        Special_Requests=request.POST.get('specialrequests')
        user_name=request.POST.get('user_name')
        amount=request.POST.get('amount')
        book_id = str(uuid.uuid4())
        book=booking(booking_id=book_id,place_name=name,user_name=user_name,Mobie_number=phone,Adhar_card=adharcard,date_arrivale=checkin,date_return=checkout,adults_kids=children,Room_type=roomtype,Special_Requests=Special_Requests,amount=amount) 
        book.save()
        Travelers=(children)+(adults)
        book_detai={
        'place_name':name,
        'date_arrivale':checkin,
        'adults_kids':Travelers,
       }
        pack=package.objects.all()
        request.session['place']=name
        request.session['in']=checkin
        request.session['out']=checkout
        request.session['guest']=Travelers
        request.session['booking_id']=book_id
        user=request.user
        return render(request,'home/payment.html',{'book_detai':book_detai,'pack':pack,'user':user})
    place=request.GET.get('place_name')
    return render(request,"home/booking.html",{'place':place})

def bookingcon(request):
     name=request.session['place']
     checkin=request.session['in']
     checkout=request.session['out']
     Travelers=request.session['guest']
     booking_id= request.session['booking_id']
     pack=package.objects.all().filter(place_name=name)
     return render(request,"home/booking-confirmation.html",{ 'name':name,
        'checkin':checkin,
        'checkout':checkout,
        'Travelers':Travelers,
        'booking_id':booking_id,
        'pack':pack})
   
def payment_tour(request):
       
    return render(request,"home/payment.html" )  

def profile_management(request):
   
       
       
    return render(request,"home/profile-management.html" )

# image nu baki che
def profile(request):

    image=request.POST.get('user_img')
    user_name=request.GET.get('user_name')
    reg=ragister.objects.get(name="parth_ramanujj")
    reg.image=image
    print(image)
    user_name=request.GET.get('user_name')
    book=booking.objects.all()
    user=request.user
    reg=ragister.objects.all().filter(name=user)
  
    return render(request,"home/profile.html",{'book':book,'user':user,'reg':reg,'user_name':user_name})

def payment_history(request):
    return render(request,"home/payment-history.html")

def place_info(request):
   
   att=Attractions.objects.all()
   place=request.GET.get('place_name')
   pack=package.objects.all()
   feed=Feedback.objects.all()   
   user=User.objects.all() 
   user=request.user
   return render(request,"home/place_info.html",{'place':place,'pack':pack,'att':att,'feed':feed,'user':user})


def superadmin (request):
    pay=payment.objects.all()
    book=booking.objects.all()
    pack=package.objects.all()
    rate=Feedback.objects.all()
    reg=ragister.objects.all()
    user=User.objects.all()
    hotels=hotel.objects.all()
    total_users = User.objects.count()
    total_bookings = booking.objects.count()
    total_rating = Feedback.objects.count()
    r_id=request.GET.get('id')
    total_amount=0
    for p in pay:
     total_amount += p.amount 
    
    total_rating1=0 
    for f in rate:
      total_rating1 += f.rating
     
    #total_rating1 = Feedback.objects.aggregate(sum('rating'))['rating__sum']
      
    avg_rating=total_rating1/total_rating
    print(total_users,total_bookings,total_amount,avg_rating)
    adm={
        
    }
    #r_id=int(r_id)
    if r_id:
        print("yes")
        user_name=request.POST.get('customerName')
        package_name=request.POST.get('Package')
        rating=request.POST.get('rating')
        discription=request.POST.get('comment')
        rat=Feedback.objects.get(Rating_id=r_id)
        rat.user_name=user_name
        rat.package_name=package_name
        rat.rating=rating
        rat.discription=discription
        rat.r_date= request.POST.get('date')
        rat.save() 
       
        packagename=request.POST.get('packagename')
        print(packagename,"yes")
    
    return render(request,"admin/admin.html",{'pay':pay,'num':range(1, total_users),'book':book,'pack':pack,'rat':rate,'reg':reg,'user':user,'hotels':hotels,'total_users':total_users,
        'total_bookings':total_bookings,
        'total_amount':total_amount,
        'avg_rating':avg_rating})


def Review(request):
    
    if request.method=="POST":
        #Review_user=Feedback.objects.all()
        place_name=request.POST.get('place_name')
        Review_user=request.POST.get('review')
        star=request.POST.get('star')
        user_name=request.POST.get('name')
        r_date= date.today()
        feedback=Feedback(package_name=place_name,rating=star,discription=Review_user,r_date=r_date,user_name=user_name)
        feedback.save()
        
        feed=Feedback.objects.all()
        place=request.GET.get('place_name')  
        pack=package.objects.all()
        att=Attractions.objects.all()
        return render(request,"home/place_info.html",{'feed':feed,'place':place,'pack':pack,'att':att})  
    else:
        pack=package.objects.all()
        user=User.objects.all()
        user_name=request.user
        place=request.GET.get('place_name')  
    return render(request,"home/Review.html",{'user':user,'pack':pack,'place':place,'un':user_name})     
    


def tourcondition(request):
    filepath = os.path.join('tour_and_travalling/templates', 'tourcondition.pdf')
    return FileResponse(open(filepath, 'rb'), content_type='application/pdf')
#manage admin panal



def managebooking(request):
    return render(request,"admin/managebooking.html")


def manageuser(request):
    if request.method == "POST":
          name=request.POST.get('customerName')
          email=request.POST.get('customerEmail')
          password=request.POST.get('pass')
          conpassword=request.POST.get('cpass')
          image=request.POST.get('image')
          reg=ragister(name=name,email_id=email,password=password,conpassword=conpassword,image=image)
          reg.save()
          my_use=User.objects.create_user(name,email,password)
          my_use.save()
          return redirect("index")
    return render(request,"admin/manageuser.html")


def manageplace(request):
    
    return render(request,"admin/manageplace.html")


def managehotel(request):
    return render(request,"admin/managehotel.html")


def managepackeg(request):
        print("in the manage pack")
        if request.method == "POST":
            print("int post")
            return render(request,"admin/managepackeg.html")
        return render(request,"admin/managepackeg.html")


def managefeedback(request):
    return render(request,"admin/managefeedback.html")
def addpack(request):
    if request.method == "POST":  
     print("in add pack")
    else:
       print(request.GET.get('packagename'))
        
    return render(request,"admin/managepackeg.html")

def managepayment(request):
    
    return render(request,"admin/managepayment.html")


def managerating(request):
    r_id=request.GET.get('id')
   
    rat=Feedback.objects.all()
    return render(request,"admin/managerating.html",{'rat':rat,'r_id':int(r_id)})

def upi(request):
    # name=request.session['name']
    # pack=package.objects.all().filter(place_name=name)
    price=request.GET.get('price') 
    return render(request,"home/upi.html",{'price':price})

    

def managedelete(request):
    r_id=request.GET.get('d_id')
    u_id=request.GET.get('id')
    if r_id:
        rat=Feedback.objects.get(Rating_id=r_id)
        rat.delete()
    if u_id:
        print("in user delete")
        user = ragister.objects.get(user_id=u_id)
        user.delete()
    
    return redirect("superadmin")

def showuserdata(request):
    r_id=request.GET.get('id')
    r_id=int(r_id)
    reg=ragister.objects.all().filter(user_id=r_id)
    
    return render(request,"admin/showuserdata.html",{'reg':reg})

def showhotel(request):
    r_id=request.GET.get('id')
    r_id=int(r_id)
    hot=hotel.objects.all().filter(user_id=r_id)
    
    return render(request,"admin/showuserdata.html",{'hot':hot})