from django.contrib import admin
from tour_and_travalling.models import *
admin.site.register(user_login)
admin.site.register(ragister)
admin.site.register(booking)
admin.site.register(Feedback)
admin.site.register(payment)
admin.site.register(package)
admin.site.register(Attractions)
admin.site.register(hotel)
# Register your models here.
