from django.apps import AppConfig


class TourAndTravallingConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tour_and_travalling'
